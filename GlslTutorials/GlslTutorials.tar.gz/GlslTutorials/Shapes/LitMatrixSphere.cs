using OpenTK;
using System;

namespace GlslTutorials
{
	public class LitMatrixSphere
	{
		public LitMatrixSphere (float radius)
		{
		}
		
		public void SetOffset(Vector3 offset)
		{
		}
		
		public void Draw()
		{
		}
	}
}

