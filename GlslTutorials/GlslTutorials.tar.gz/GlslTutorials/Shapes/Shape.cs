using System;

namespace GlslTutorials
{
	public class Shape
	{
		public Shape ()
		{
		}
	}
}

