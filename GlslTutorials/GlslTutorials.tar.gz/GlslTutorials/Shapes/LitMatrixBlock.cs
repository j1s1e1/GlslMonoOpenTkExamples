using OpenTK;
using System;

namespace GlslTutorials
{
	public class LitMatrixBlock
	{
		public LitMatrixBlock (Vector3 size, float[] color)
		{
		}
		
		public void SetOffset(Vector3 offset)
		{
		}
		
		public void Draw()
		{
		}
	}
}

