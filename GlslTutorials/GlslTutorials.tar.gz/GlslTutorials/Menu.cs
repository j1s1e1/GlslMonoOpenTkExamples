using System;
using System.Collections.Generic;

namespace GlslTutorials
{
	public enum TutorialsEnum
	{
		Tut_02_Vertex_Colors,
		Tut_TiltBall
	}
	public class MenuClass
	{
		public MenuClass ()
		{
		}
		
		
		
		public static List<string> FillTestlist()
		{
			List<string> TestList = new List<string>();
			
			TestList.Add(TutorialsEnum.Tut_02_Vertex_Colors.ToString());
			TestList.Add(TutorialsEnum.Tut_TiltBall.ToString());
			return TestList;
		}
	}
}

