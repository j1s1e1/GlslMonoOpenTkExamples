using System;

namespace GlslTutorials
{
	public class Colors
	{
		public Colors ()
		{
		}
		
		public static float[] RED_COLOR = new float[]{1f, 0f, 0f, 1f};
		public static float[] GREEN_COLOR = new float[]{0f, 1f, 0f, 1f};
		public static float[] BLUE_COLOR = new float[]{0f, 0f, 1f, 1f};
		public static float[] YELLOW_COLOR = new float[]{1f, 1f, 0f, 1f};
		public static float[] CYAN_COLOR = new float[]{0f, 1f, 1f, 1f};
		public static float[] BROWN_COLOR = new float[]{165f/255f, 42f/255f, 42f/255f, 1f};
		public static float[] WHITE_COLOR = new float[]{1f, 1f, 1f, 1f};
	}
}

