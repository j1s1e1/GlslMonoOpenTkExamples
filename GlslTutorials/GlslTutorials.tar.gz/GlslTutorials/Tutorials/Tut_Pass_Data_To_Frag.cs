using System;

namespace GlslTutorials
{
	public class Tut_Pass_Data_To_Frag : TutorialBase
	{
		public Tut_Pass_Data_To_Frag ()
		{
		}
	}
}

