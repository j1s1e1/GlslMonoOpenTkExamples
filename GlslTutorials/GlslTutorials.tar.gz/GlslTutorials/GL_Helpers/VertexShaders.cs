using System;

namespace GlslTutorials
{
	public class VertexShaders
	{
		public VertexShaders ()
		{
		}
	}
}

