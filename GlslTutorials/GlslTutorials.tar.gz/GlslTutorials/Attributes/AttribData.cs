using System;

namespace GlslTutorials
{
	public class AttribData
	{
		public float fValue;
	    public uint uiValue;
	    public ushort usValue;
	    public byte ubValue;
	}
}

